const quizData = [
    {
        question: "1. What is phishing?",
        options: [
            "A method to catch fish online",
            "A cyberattack where attackers steal sensitive information",
            "A type of computer hardware",
            "A game played online"
        ],
        answer: 1
    },
    {
        question: "2. Which of the following is a phishing red flag?",
        options: [
            "Proper grammar",
            "Unexpected attachments",
            "A known email sender",
            "Verified website link"
        ],
        answer: 1
    },
    {
        question: "3. What should you do if you receive a suspicious email?",
        options: [
            "Click the link to check",
            "Reply immediately",
            "Report it and delete it",
            "Forward it to friends"
        ],
        answer: 2
    },
    {
        question: "4. Phishing can happen through:",
        options: [
            "Email",
            "SMS",
            "Social media",
            "All of the above"
        ],
        answer: 3
    },
    {
        question: "5. A phishing email usually tries to create:",
        options: [
            "Urgency and fear",
            "Comfort",
            "Relaxation",
            "Motivation"
        ],
        answer: 0
    },
    {
        question: "6. Which link is safer?",
        options: [
            "http://secure-login-bank.com.fake-site.com",
            "https://yourbank.com",
            "Click here to verify now!",
            "Your account will be locked soon!"
        ],
        answer: 1
    }
];

let index = 0;
let score = 0;

const startBtn = document.getElementById("startQuiz");
const quizSection = document.getElementById("quiz");
const contentSection = document.getElementById("content");
const resultSection = document.getElementById("result");

startBtn.onclick = () => {
    contentSection.style.display = "none";
    quizSection.style.display = "block";
    loadQuestion();
};

function loadQuestion() {
    document.getElementById("question").innerText = quizData[index].question;

    const optionsDiv = document.getElementById("options");
    optionsDiv.innerHTML = "";

    quizData[index].options.forEach((option, i) => {
        const btn = document.createElement("button");
        btn.innerText = option;
        btn.onclick = () => checkAnswer(i);
        optionsDiv.appendChild(btn);
    });
}

function checkAnswer(selected) {
    if (selected === quizData[index].answer) {
        score++;
    }
    index++;

    if (index < quizData.length) {
        loadQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    quizSection.style.display = "none";
    resultSection.style.display = "block";

    document.getElementById("score").innerText = `${score} / ${quizData.length}`;

    let detailText = "";
    quizData.forEach((q, i) => {
        detailText += `<p><strong>Q${i + 1}:</strong> ${q.question}<br>
                       <strong>Correct Answer:</strong> ${q.options[q.answer]}</p>`;
    });

    document.getElementById("details").innerHTML = detailText;
}

document.getElementById("restartBtn").onclick = () => {
    window.location.reload();
};
