#!/usr/bin/env python3
import subprocess, json, sys
from datetime import datetime
from pathlib import Path

def run_bandit(target, out_json="bandit_out.json"):
    cmd = ["bandit", "-r", target, "-f", "json", "-o", out_json]
    subprocess.run(cmd, check=False)
    return Path(out_json).read_text() if Path(out_json).exists() else "{}"

def run_pylint(target, out_txt="pylint_out.txt"):
    cmd = ["pylint", target, "--output-format=text"]
    with open(out_txt, "w") as f:
        subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, check=False)
    return Path(out_txt).read_text() if Path(out_txt).exists() else ""

def generate_report(bandit_json_str, pylint_txt, out_report="report.md"):
    now = datetime.utcnow().isoformat()
    with open(out_report, "w") as f:
        f.write(f"# Secure Code Review Report\nGenerated: {now} UTC\n\n")
        f.write("## Bandit Findings\n\n```
")
        f.write(bandit_json_str[:3000] + "\n```
\n")
        f.write("## Pylint Output\n\n```
")
        f.write(pylint_txt[:3000] + "\n```
\n")
        f.write("## Summary & Recommendations\n- Fix high-risk Bandit warnings\n- Improve code style based on pylint\n")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python run_scan.py <target_folder>")
        sys.exit(1)
    target = sys.argv[1]
    bandit_json = run_bandit(target)
    pylint_txt = run_pylint(target)
    generate_report(bandit_json, pylint_txt)
