#!/usr/bin/env python3
# Simple NIDS demo

import argparse, json, time
from collections import defaultdict, deque
from pathlib import Path
from scapy.all import sniff, IP, TCP, UDP, Raw

ALERT_LOG = "alert.log"
SYN_WINDOW = 10
SYN_THRESHOLD = 30
PORTSCAN_WINDOW = 20
PORTSCAN_PORT_THRESHOLD = 50

recent_syns = defaultdict(deque)
distinct_ports = defaultdict(lambda: deque())
suspicious_hosts = set()

def log_alert(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"{ts} ALERT: {msg}"
    print(line)
    with open(ALERT_LOG, "a") as f:
        f.write(line + "\n")

def load_rules(path):
    try:
        return json.load(open(path, "r"))
    except:
        return {}

def check_syn(pkt):
    if pkt.haslayer(TCP):
        flags = pkt[TCP].flags
        try:
            syn = bool(int(flags) & 0x02)
        except:
            syn = "S" in str(flags)
        if syn:
            src = pkt[IP].src
            now = time.time()
            dq = recent_syns[src]
            dq.append(now)
            while dq and now - dq[0] > SYN_WINDOW:
                dq.popleft()
            if len(dq) >= SYN_THRESHOLD and src not in suspicious_hosts:
                log_alert(f"SYN flood suspected from {src}")
                suspicious_hosts.add(src)

def check_portscan(pkt):
    if pkt.haslayer(TCP) or pkt.haslayer(UDP):
        src = pkt[IP].src
        dport = pkt[TCP].dport if pkt.haslayer(TCP) else pkt[UDP].dport
        now = time.time()
        dq = distinct_ports[src]
        dq.append((now, dport))
        while dq and now - dq[0][0] > PORTSCAN_WINDOW:
            dq.popleft()
        if len({p for t, p in dq}) >= PORTSCAN_PORT_THRESHOLD and src not in suspicious_hosts:
            log_alert(f"Portscan suspected from {src}")
            suspicious_hosts.add(src)

def check_http(pkt, rules):
    allowed = rules.get("allowed_http_hosts", [])
    if pkt.haslayer(Raw) and b"HTTP" in bytes(pkt[Raw]):
        payload = bytes(pkt[Raw])
        for line in payload.split(b"\r\n"):
            if line.lower().startswith(b"host:"):
                host = line.split(b":", 1)[1].strip().decode(errors="ignore")
                if allowed and host not in allowed:
                    log_alert(f"HTTP anomaly from {pkt[IP].src}: host={host}")

def pkt_handler(pkt, rules):
    if not pkt.haslayer(IP):
        return
    check_syn(pkt)
    check_portscan(pkt)
    check_http(pkt, rules)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--iface", "-i", default=None)
    parser.add_argument("--rules", "-r", default="rules.json")
    parser.add_argument("--filter", "-f", default="ip")
    args = parser.parse_args()

    rules = load_rules(args.rules)
    print("Rules loaded:", rules)
    print("NIDS started. Press Ctrl+C to stop.")
    sniff(iface=args.iface, prn=lambda p: pkt_handler(p, rules), store=False, filter=args.filter)

if __name__ == "__main__":
    main()
