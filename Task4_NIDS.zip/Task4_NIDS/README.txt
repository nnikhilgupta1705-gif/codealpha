Task 4 - Network Intrusion Detection System (NIDS)

Run instructions:
1. Install Npcap on Windows (WinPcap API compatible mode).
2. Install scapy:
   pip install scapy

3. Run the NIDS:
   python nids.py --iface "Wi-Fi" --rules rules.json

4. Alerts will appear in alert.log.
